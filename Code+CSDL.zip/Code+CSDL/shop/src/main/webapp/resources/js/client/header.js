$(document).ready(function () {
  ajaxGet2();
  function ajaxGet2() {
    $.ajax({
      type: "GET",
      url: "http://localhost:8080/api/danh-muc/allForReal",
      success: function (result) {
        $.each(result, function (i, danhmuc) {
          var content =
            '<li><a href="/store?brand=' +
            danhmuc.tenDanhMuc +
            '"><span style=" font-size: 16px; font-weight: 900; ">' +
            danhmuc.tenDanhMuc +
            "</span></a></li>";
          $("#danhmuc").append(content);
          $("#danhmuc2").append(content);
        });
      },
    });
  }
});
