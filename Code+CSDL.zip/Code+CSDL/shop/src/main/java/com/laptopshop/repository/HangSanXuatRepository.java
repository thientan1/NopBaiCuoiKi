package com.laptopshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.laptopshop.entities.HangSanXuat;

public interface HangSanXuatRepository extends JpaRepository<HangSanXuat, Long>{

}
