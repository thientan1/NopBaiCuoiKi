-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th4 20, 2022 lúc 02:18 PM
-- Phiên bản máy phục vụ: 10.4.22-MariaDB
-- Phiên bản PHP: 7.4.26

CREATE DATABASE  IF NOT exists `online_store` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `online_store`;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `online_store`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_muc_gio_hang`
--

CREATE TABLE `chi_muc_gio_hang` (
  `id` bigint(20) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `ma_gio_hang` bigint(20) DEFAULT NULL,
  `ma_san_pham` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_tiet_don_hang`
--

CREATE TABLE `chi_tiet_don_hang` (
  `id` bigint(20) NOT NULL,
  `don_gia` bigint(20) NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `ma_don_hang` bigint(20) DEFAULT NULL,
  `ma_san_pham` bigint(20) DEFAULT NULL,
  `so_luong_dat` int(11) NOT NULL,
  `so_luong_nhan_hang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `chi_tiet_don_hang`
--

INSERT INTO `chi_tiet_don_hang` (`id`, `don_gia`, `so_luong`, `ma_don_hang`, `ma_san_pham`, `so_luong_dat`, `so_luong_nhan_hang`) VALUES
(9, 49999995, NULL, 34, 154, 5, 5),
(10, 1230000, NULL, 34, 111, 1, 1),
(11, 888888888, NULL, 35, 149, 1, 0),
(12, 599999994, NULL, 36, 156, 6, 6),
(13, 29999997, NULL, 36, 154, 3, 3),
(14, 10000000, NULL, 37, 157, 1, 0),
(15, 9999999, NULL, 37, 153, 1, 0),
(16, 9999999, NULL, 38, 152, 1, 1),
(17, 120000, NULL, 38, 124, 1, 1),
(18, 120000, NULL, 38, 139, 1, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_muc`
--

CREATE TABLE `danh_muc` (
  `id` bigint(20) NOT NULL,
  `ten_danh_muc` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `danh_muc`
--

INSERT INTO `danh_muc` (`id`, `ten_danh_muc`) VALUES
(1, 'Điện Thoại'),
(2, 'PC ĐỒNG BỘ & PC GAMING'),
(3, 'TB NGHE NHÌN & GIẢI TRÍ'),
(4, 'LINH KIỆN MÁY TÍNH'),
(5, 'THIẾT BỊ LƯU TRỮ'),
(6, 'THIẾT BỊ MẠNG'),
(7, 'CAMERA QUAN SÁT'),
(8, 'PHỤ KIỆN CÁC LOẠI'),
(9, 'THIẾT BỊ VĂN PHÒNG'),
(11, 'LAPTOP');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `don_hang`
--

CREATE TABLE `don_hang` (
  `id` bigint(20) NOT NULL,
  `dia_chi_nhan` varchar(255) DEFAULT NULL,
  `ghi_chu` varchar(255) DEFAULT NULL,
  `ho_ten_nguoi_nhan` varchar(255) DEFAULT NULL,
  `ngay_dat_hang` datetime DEFAULT NULL,
  `ngay_giao_hang` datetime DEFAULT NULL,
  `ngay_nhan_hang` datetime DEFAULT NULL,
  `sdt_nhan_hang` varchar(255) DEFAULT NULL,
  `trang_thai_don_hang` varchar(255) DEFAULT NULL,
  `ma_nguoi_dat` bigint(20) DEFAULT NULL,
  `ma_shipper` bigint(20) DEFAULT NULL,
  `tong_gia_tri` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `don_hang`
--

INSERT INTO `don_hang` (`id`, `dia_chi_nhan`, `ghi_chu`, `ho_ten_nguoi_nhan`, `ngay_dat_hang`, `ngay_giao_hang`, `ngay_nhan_hang`, `sdt_nhan_hang`, `trang_thai_don_hang`, `ma_nguoi_dat`, `ma_shipper`, `tong_gia_tri`) VALUES
(31, 'bd', 'asdf', 'aaa', '2018-12-01 14:38:26', NULL, NULL, 'dsf', 'Đang chờ duyệt', NULL, NULL, 0),
(32, 'fadf', 'asdf', 'aaa', '2018-12-05 21:58:24', NULL, NULL, '13', 'created', 2, NULL, 0),
(33, '26 Nguyễn Tạo', 'Ghi chú shipper: \nok<br> Ghi chú admin:\nokie', 'Quang', '2022-04-17 01:09:31', '2022-04-17 01:23:40', '2022-04-17 01:24:02', '0973617935', 'Hoàn thành', 2, 3, 137380000),
(34, 'okkkkk', 'Ghi chú shipper: \nĐã giao hàng<br> Ghi chú admin:\nXác nhận', 'Qunag', '2022-04-17 16:19:36', '2022-04-17 16:21:31', '2022-04-17 16:22:27', '0123456783', 'Hoàn thành', 2, 3, 51229995),
(35, 'aaaa', NULL, 'Qunag', '2022-04-17 16:23:39', NULL, NULL, '0123456783', 'Đã bị hủy', 2, NULL, 888888888),
(36, '24ggrege', 'Ghi chú shipper: \nĐã giao<br> Ghi chú admin:\nOkie', 'Qunag', '2022-04-18 13:11:07', '2022-04-18 13:12:54', '2022-04-18 13:13:39', '0123456783', 'Hoàn thành', 2, 3, 629999991),
(37, 'ffff', NULL, 'Qunag', '2022-04-18 13:14:31', NULL, NULL, '0123456783', 'Đã bị hủy', 2, NULL, 19999999),
(38, 'dưdfwefe', 'Ghi chú shipper: \nGiao rồi nhé<br> Ghi chú admin:\nokie rồi đó', 'Qunag', '2022-04-18 13:17:12', '2022-04-18 13:18:12', '2022-04-18 13:18:40', '0123456783', 'Hoàn thành', 2, 5, 10239999);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `gio_hang`
--

CREATE TABLE `gio_hang` (
  `id` bigint(20) NOT NULL,
  `tong_tien` varchar(255) DEFAULT NULL,
  `ma_nguoi_dung` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `gio_hang`
--

INSERT INTO `gio_hang` (`id`, `tong_tien`, `ma_nguoi_dung`) VALUES
(1, NULL, 2),
(2, NULL, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hang_san_xuat`
--

CREATE TABLE `hang_san_xuat` (
  `id` bigint(20) NOT NULL,
  `ten_hang_san_xuat` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `hang_san_xuat`
--

INSERT INTO `hang_san_xuat` (`id`, `ten_hang_san_xuat`) VALUES
(2, 'Apple'),
(3, 'Asus'),
(4, 'Acer'),
(5, 'Dell'),
(6, 'HP'),
(7, 'Lenovo'),
(8, 'MSI'),
(9, 'Masstel'),
(10, 'Haier'),
(11, 'Oppo'),
(12, 'Xiaomi'),
(13, 'Samsung'),
(14, 'Vivo'),
(15, 'Redmi');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lien_he`
--

CREATE TABLE `lien_he` (
  `id` bigint(20) NOT NULL,
  `email_lien_he` varchar(255) DEFAULT NULL,
  `ngay_lien_he` datetime DEFAULT NULL,
  `ngay_tra_loi` datetime DEFAULT NULL,
  `noi_dung_lien_he` varchar(255) DEFAULT NULL,
  `noi_dung_tra_loi` varchar(255) DEFAULT NULL,
  `trang_thai` varchar(255) DEFAULT NULL,
  `ma_nguoi_tra_loi` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `lien_he`
--

INSERT INTO `lien_he` (`id`, `email_lien_he`, `ngay_lien_he`, `ngay_tra_loi`, `noi_dung_lien_he`, `noi_dung_tra_loi`, `trang_thai`, `ma_nguoi_tra_loi`) VALUES
(1, 'hnquang.20it9@vku.udn.vn', '2022-04-17 01:26:45', NULL, 'mua hàng', NULL, 'Đang chờ trả lời', NULL),
(2, 'hnquang.20it9@vku.udn.vn', '2022-04-17 16:25:11', NULL, 'cửa hàng tốt quá', NULL, 'Đang chờ trả lời', NULL),
(3, 'member@gmail.com', '2022-04-18 13:21:40', NULL, 'tư vấn giúp tôi', NULL, 'Đang chờ trả lời', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoidung_vaitro`
--

CREATE TABLE `nguoidung_vaitro` (
  `ma_nguoi_dung` bigint(20) NOT NULL,
  `ma_vai_tro` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `nguoidung_vaitro`
--

INSERT INTO `nguoidung_vaitro` (`ma_nguoi_dung`, `ma_vai_tro`) VALUES
(1, 1),
(1, 2),
(2, 2),
(3, 3),
(4, 2),
(5, 3);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoi_dung`
--

CREATE TABLE `nguoi_dung` (
  `id` bigint(20) NOT NULL,
  `dia_chi` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `ho_ten` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `so_dien_thoai` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `nguoi_dung`
--

INSERT INTO `nguoi_dung` (`id`, `dia_chi`, `email`, `ho_ten`, `password`, `so_dien_thoai`) VALUES
(1, '26 Nguyễn Tạo', 'admin@gmail.com', 'Hoàng Nhật Quang', '$2a$10$/VFMNUPBKNVRMjxPFCYKZ.lKahoLQda0EaAxdqoun1w3DqwNLa2me', '123456789'),
(2, 'Ky Phong - Ky Anh - Ha Tinh', 'member@gmail.com', 'Hoàng Nhật Quang', '$2a$10$j7Upgupou72GBmukz0G6pOATk3wlCAgaoFCEqAhSvLToD/V/1wlpu', '0973617935'),
(3, 'fvvrg', 'shipper@gmail.com', 'Shipper nè', '$2a$10$u2B29HDxuWVYY3fUJ8R2qunNzXngfxij5GpvlFAEtIz3JpK/WFXF2', '11111111'),
(4, 'Ha Noi', 'jvgiveup@gmail.com', 'Pham Tuan', '$2a$10$ZCqCO9gSWt8A8HNXAWq8luqfNbJm0uG3PsUlzry0aRLwO3VHQZTmy', '123456'),
(5, '26 Nguyễn Tạo', 'shipper2@gmail.com', 'Shipper 2 nè', '$2a$10$q5MlPBEDIWIynmYc452tHeTPctjxkGk4FkmNG/62gKE8GCjEVEywW', '0123456789');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `san_pham`
--

CREATE TABLE `san_pham` (
  `id` bigint(20) NOT NULL,
  `cpu` varchar(255) DEFAULT NULL,
  `don_gia` bigint(20) NOT NULL,
  `don_vi_ban` int(11) NOT NULL,
  `don_vi_kho` int(11) NOT NULL,
  `dung_luong_pin` varchar(255) DEFAULT NULL,
  `he_dieu_hanh` varchar(255) DEFAULT NULL,
  `man_hinh` varchar(255) DEFAULT NULL,
  `ram` varchar(255) DEFAULT NULL,
  `ten_san_pham` varchar(255) DEFAULT NULL,
  `thiet_ke` varchar(255) DEFAULT NULL,
  `thong_tin_bao_hanh` varchar(255) DEFAULT NULL,
  `thong_tin_chung` varchar(255) DEFAULT NULL,
  `ma_danh_muc` bigint(20) DEFAULT NULL,
  `ma_hang_sx` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `san_pham`
--

INSERT INTO `san_pham` (`id`, `cpu`, `don_gia`, `don_vi_ban`, `don_vi_kho`, `dung_luong_pin`, `he_dieu_hanh`, `man_hinh`, `ram`, `ten_san_pham`, `thiet_ke`, `thong_tin_bao_hanh`, `thong_tin_chung`, `ma_danh_muc`, `ma_hang_sx`) VALUES
(85, NULL, 15000000, 0, 80, NULL, NULL, NULL, NULL, 'PC Lenovo ThinkCentre V520 10NKA00TVA i7 7700/4GB/1TB/DVDRW/K+M/Dos', NULL, '6 tháng', 'CPU i7-7700(3.6GHz/8MB) \r\nRAM 4GB DDR4 \r\nHDD 1TB 7200RPM, \r\nDVDRW, \r\nUSB Calliope Keyboard,USB Mouse', 2, 7),
(86, NULL, 10500000, 0, 90, NULL, NULL, NULL, NULL, 'PC Lenovo IdeaCentre 510-15IKL 90G800HEVN Pentium G4560/4GB/1TB/DVDRW/WL/K+M/Win10', NULL, '6 tháng', '-	Bộ vi xử lý: Intel Core i3-7100 ( 3.90 GHz / 3MB cache ) \r\n-	RAM: 4GB DDR4 2400UDIMM \r\n-	Ổ cứng: 1TB SATA 7200RPM \r\n-	VGA: Intel® HD Graphics 630', 2, 7),
(87, NULL, 10500000, 0, 90, NULL, NULL, NULL, NULL, 'PC Lenovo V530S-07ICB i3 8100/4GB/1TB/K+M/WL/Win10 ( 10TXA000VN )', NULL, '6 tháng', 'PC Lenovo V530S-07ICB - 10TXA000VN \r\nBộ vi xử lý Intel Core i3 8100 3.6Ghz \r\nRAM 4GB/ HDD 1TB/ K+M/ WL/ Win10', 2, 7),
(88, NULL, 124000000, 0, 80, NULL, NULL, NULL, NULL, 'PC Lenovo ThinkCentre V520 10NKA00TVA i7 7700/4GB/1TB/DVDRW/K+M/Dos', NULL, '6 tháng', 'CPU i7-7700(3.6GHz/8MB) \r\nRAM 4GB DDR4 \r\nHDD 1TB 7200RPM, \r\nDVDRW, \r\nUSB Calliope Keyboard,USB Mouse', 2, 7),
(89, NULL, 2800500, 0, 100, NULL, NULL, NULL, NULL, 'Tai nghe ASUS ROG Strix Fusion 300 Surround 7.1', NULL, '6 tháng', 'Tai nghe chơi game cao cấp từ ASUS ROG \r\nMàng loa dài 50mm \r\nGiả lập âm thanh vòm 7.1 \r\nThiết kế trùm tai cho độ thoải mái tối đa \r\nHệ thống Led màu đỏ nổi bật \r\nCó thể sử dụng 3,5mm và USB linh hoạt', 3, 3),
(90, NULL, 3200000, 0, 120, NULL, NULL, NULL, NULL, 'Tai nghe ASUS ROG Strix Fusion Wireless', NULL, '6 tháng', 'Tai nghe chơi game cao cấp từ ASUS ROG \r\nMàng loa dài 50mm \r\nGiả lập âm thanh vòm 7.1 \r\nThiết kế trùm tai cho độ thoải mái tối đa \r\nKết nối không dây No-Lag qua USB Receiver', 3, 3),
(91, NULL, 10000000, 0, 90, NULL, NULL, NULL, NULL, 'Tai nghe ASUS ROG Strix Fusion 500', NULL, '6 tháng', 'Tai nghe chơi game cao cấp từ ASUS ROG \r\nMàng loa dài 50mm \r\nGiả lập âm thanh vòm 7.1 \r\nThiết kế trùm tai cho độ thoải mái tối đa \r\nHệ thống Led RGB 16,8 triệu màu \r\nCó thể sử dụng 3,5mm và USB linh hoạt \r\nĐiều chỉnh qua bề mặt cảm ứng của củ tai', 3, 3),
(92, NULL, 4200123, 0, 100, NULL, NULL, NULL, NULL, 'Tai nghe Asus STRIX 2.0- ROG Gaming Headset', NULL, '6 tháng', 'Tai nghe chơi game cao cấp từ ASUS ROG \r\nMàng loa dài 50mm \r\nGiả lập âm thanh vòm 7.1 \r\nThiết kế trùm tai cho độ thoải mái tối đa \r\nHệ thống Led RGB 16,8 triệu màu \r\nCó thể sử dụng 3,5mm và USB linh hoạt \r\nĐiều chỉnh qua bề mặt cảm ứng của củ tai', 3, 3),
(93, NULL, 3200000, 0, 50, NULL, NULL, NULL, NULL, 'Tai nghe Asus Centurion - ROG Gaming Headset', NULL, '6 tháng', 'Tai nghe chơi game cao cấp từ ASUS ROG \r\nMàng loa dài 50mm \r\nGiả lập âm thanh vòm 7.1 \r\nThiết kế trùm tai cho độ thoải mái tối đa \r\nKết nối không dây No-Lag qua USB Receiver', 3, 3),
(94, NULL, 1002356, 0, 60, NULL, NULL, NULL, NULL, 'Tai Nghe Asus CERBERUS V2 - Red / Black', NULL, '6 tháng', 'Tai nghe chơi game cao cấp từ ASUS ROG \r\nMàng loa dài 50mm \r\nGiả lập âm thanh vòm 7.1 \r\nThiết kế trùm tai cho độ thoải mái tối đa \r\nKết nối không dây No-Lag qua USB Receiver', 3, 3),
(95, NULL, 2500000, 0, 70, NULL, NULL, NULL, NULL, 'Tai nghe Asus Gaming Asus Strix Pro', NULL, '6 tháng', 'Tai nghe chơi game cao cấp từ ASUS ROG \r\nMàng loa dài 50mm \r\nGiả lập âm thanh vòm 7.1 \r\nThiết kế trùm tai cho độ thoải mái tối đa \r\nKết nối không dây No-Lag qua USB Receiver', 3, 3),
(96, NULL, 3000000, 0, 100, NULL, NULL, NULL, NULL, 'Tai nghe Asus gaming ROG Strix Wireless', NULL, '6 tháng', 'Tai nghe chơi game cao cấp từ ASUS ROG \r\nMàng loa dài 50mm \r\nGiả lập âm thanh vòm 7.1 \r\nThiết kế trùm tai cho độ thoải mái tối đa \r\nKết nối không dây No-Lag qua USB Receiver', 3, 3),
(97, NULL, 43000000, 0, 100, NULL, NULL, NULL, NULL, 'Màn hình Acer Nitro 23.8\"VG240Y LED IPS', NULL, '6 tháng', 'Kích Thước Màn Hình	23.8 INCH \r\nĐộ Sáng Màn Hình	250 cd/m² \r\nTỉ Lệ Tương Phản Động MEGA	100,000,000:1 \r\nĐộ Phân Giải Màn Hình	1920*1080 \r\nThời Gian Đáp Ứng	1ms \r\nHỗ trợ màu	16.7 million colours \r\nGóc nhìn	178/178', 4, 4),
(98, NULL, 50000000, 0, 200, NULL, NULL, NULL, NULL, 'Monitor Acer 21.5\"R221Q LED IPS', NULL, '6 tháng', 'Kích Thước Màn Hình	23.8 INCH \r\nĐộ Sáng Màn Hình	250 cd/m² \r\nTỉ Lệ Tương Phản Động MEGA	100,000,000:1 \r\nĐộ Phân Giải Màn Hình	1920*1080 \r\nThời Gian Đáp Ứng	1ms \r\nHỗ trợ màu	16.7 million colours \r\nGóc nhìn	178/178', 4, 4),
(99, NULL, 5200000, 0, 100, NULL, NULL, NULL, NULL, 'Màn hình Acer 19.5\"K202HQL LED', NULL, '6 tháng', 'Kích Thước Màn Hình	27\'\' \r\nĐộ Sáng Màn Hình	350 cd/m² \r\nĐộ Phân Giải Màn Hình	2560 x 1440 \r\nThời Gian Đáp Ứng	1ms \r\nHỗ trợ màu	16,7 Triệu Màu \r\nGóc nhìn	178°/178° \r\nTín hiệu đầu vào	HDMI, DP \r\nMức Tiêu Thụ̣ Điện	26W', 4, 4),
(100, NULL, 2000000, 0, 100, NULL, NULL, NULL, NULL, 'Màn hình Acer Nitro 27\"VG270 LED IPS', NULL, '6 tháng', 'Size	27” \r\nĐộ phân giải	Full HD (1920 x 1080) \r\nTỷ lệ khung hình	16:9 \r\nThời gian đáp ứng: 1 ms \r\nRefresh Rate	75 Hz \r\nHỗ trợ màu	16.7 million \r\nĐộ sáng	250 cd/m² \r\nBacklight	LED', 4, 4),
(101, NULL, 1200000, 0, 12, NULL, NULL, NULL, NULL, 'Màn hình Acer 18.5\"EB192Q LED', NULL, '6 tháng', 'Kích Thước Màn Hình	23.8 INCH \r\nĐộ Sáng Màn Hình	250 cd/m² \r\nTỉ Lệ Tương Phản Động MEGA	100,000,000:1 \r\nĐộ Phân Giải Màn Hình	1920*1080 \r\nThời Gian Đáp Ứng	1ms \r\nHỗ trợ màu	16.7 million colours \r\nGóc nhìn	178/178', 4, 4),
(102, NULL, 12000000, 0, 123, NULL, NULL, NULL, NULL, 'Màn hình Acer 27\"KG271 LED IPS', NULL, '6 tháng', 'Kích Thước Màn Hình	23.8 INCH \r\nĐộ Sáng Màn Hình	250 cd/m² \r\nTỉ Lệ Tương Phản Động MEGA	100,000,000:1 \r\nĐộ Phân Giải Màn Hình	1920*1080 \r\nThời Gian Đáp Ứng	1ms \r\nHỗ trợ màu	16.7 million colours \r\nGóc nhìn	178/178', 4, 4),
(103, NULL, 300000, 0, 123, NULL, NULL, NULL, NULL, 'Bàn Phím Asus ROG Claymore Ultimate RGB Aura Sync Cherry Red switch', NULL, '6 tháng', 'Bàn Phím Asus ROG Claymore Ultimate RGB Aura Sync Cherry Red switch', 4, 3),
(104, NULL, 4000000, 0, 123, NULL, NULL, NULL, NULL, 'Keyboard ASUS ROG Strix Flare Cherry Blue switch', NULL, '6 tháng', 'Keyboard ASUS ROG Strix Flare Cherry Blue switch', 4, 3),
(105, NULL, 5432584, 0, 123, NULL, NULL, NULL, NULL, 'Keyboard ASUS Strix Tactic Pro Mechanical Blue', NULL, '6 tháng', 'Keyboard ASUS Strix Tactic Pro Mechanical Blue', 4, 3),
(106, NULL, 1200000, 0, 123, NULL, NULL, NULL, NULL, 'Mouse ASUS ROG Strix Impact', NULL, '2 tháng', 'Mouse ASUS ROG Strix Impact', 4, 3),
(107, NULL, 100000, 0, 123, NULL, NULL, NULL, NULL, 'Mouse ASUS ROG Gladius II', NULL, '2 tháng', 'Chuột chơi game cho game thủ chuyên nghiệp của Asus ROG \r\nHệ thống led RGB tích hợp công nghệ Aura Sync với Mainboard và VGA \r\nThiết kế Ergonomics phù hợp với kiểu cầm chuột Palm Grip và Claw Grip \r\n', 4, 3),
(108, NULL, 3000000, 0, 123, NULL, NULL, NULL, NULL, 'Mouse Asus ROG Spatha - Super MMO Gaming Mouse', NULL, '2 tháng', 'Mouse Asus ROG Spatha - Super MMO Gaming Mouse\r\n', 4, 3),
(109, NULL, 200000, 0, 1000, NULL, NULL, NULL, NULL, 'MicroSDHC SILICON POWER UHS-I 32GB W/A', NULL, '2 tháng', 'MicroSDHC SILICON POWER UHS-I 32GB W/A', 5, 2),
(110, NULL, 30000, 0, 100, NULL, NULL, NULL, NULL, 'HDD Western Caviar Black 500GB 7200Rpm, SATA3 6Gb/s, 64MB Cache', NULL, '2 tháng', 'HDD Western Caviar Black 500GB 7200Rpm, SATA3 6Gb/s, 64MB Cache\r\n', 5, 2),
(111, NULL, 1230000, 1, 99, NULL, NULL, NULL, NULL, 'SSD Kingston Furry RGB 240GB Sata3 2.5\" (Doc 550MB/s, Ghi 480MB/s) - SHFR200/240G', NULL, '2 tháng', 'SSD Kingston Furry RGB 240GB Sata3 2.5\" (Doc 550MB/s, Ghi 480MB/s) - SHFR200/240G', 5, 3),
(112, NULL, 1230000, 0, 1000, NULL, NULL, NULL, NULL, 'SSD AVEXIR S100 White 120GB SATA3 6Gb/s 2.5\" (Read 550MB/s, Write 275MB/s)', NULL, '2 tháng', 'SSD AVEXIR S100 White 120GB SATA3 6Gb/s 2.5\" (Read 550MB/s, Write 275MB/s)', 5, 2),
(113, NULL, 1200000, 0, 100, NULL, NULL, NULL, NULL, 'Handy Kingston 32GB DATA TRAVELER DT SWIVL USB 3.0', NULL, '2 tháng', 'Handy Kingston 32GB DATA TRAVELER DT SWIVL USB 3.0', 5, 2),
(114, NULL, 100000, 0, 100, NULL, NULL, NULL, NULL, 'Handy Kingston 16GB DATA TRAVELER DT SWIVL USB 3', NULL, '2 tháng', 'Handy Kingston 16GB DATA TRAVELER DT SWIVL USB 3', 5, 2),
(115, NULL, 1200000, 0, 123, NULL, NULL, NULL, NULL, 'USB3.0 SILICON POWER Marvel M50 16GB', NULL, '2 tháng', 'USB3.0 SILICON POWER Marvel M50 16GB', 5, 2),
(116, NULL, 3000000, 0, 100, NULL, NULL, NULL, NULL, 'Router ASUS RT-N14UHP N300 3-in-1 Wi-Fi Router / Access Point / Repeater', NULL, '2 tháng', 'Router ASUS RT-N14UHP N300 3-in-1 Wi-Fi Router / Access Point / Repeater', 6, 3),
(117, NULL, 1200000, 0, 100, NULL, NULL, NULL, NULL, 'Router ASUS RT-N12+ 3-in-1 Router/AP/Range', NULL, '2 tháng', 'Router ASUS RT-N12+ 3-in-1 Router/AP/Range\r\n', 6, 3),
(118, NULL, 100000, 0, 100, NULL, NULL, NULL, NULL, 'Router ASUS RT-N12HP (Black Diamond) N300 3-in-1 Wi-Fi Router / Access Point / Repeater', NULL, '2 tháng', 'Router ASUS RT-N12HP (Black Diamond) N300 3-in-1 Wi-Fi Router / Access Point / Repeater', 6, 3),
(119, NULL, 1000000, 0, 100, NULL, NULL, NULL, NULL, 'Router ASUS RT-AC86U', NULL, '2 tháng', 'Router ASUS RT-AC86U', 6, 3),
(120, NULL, 100000, 0, 100, NULL, NULL, NULL, NULL, 'Router ASUS RT-A1300UHP', NULL, '2 tháng', 'Router ASUS RT-A1300UHP', 6, 3),
(121, NULL, 200000, 0, 100, NULL, NULL, NULL, NULL, 'Router ASUS RT-AC68U', NULL, '2 tháng', 'Router ASUS RT-AC68U', 6, 3),
(122, NULL, 230000, 0, 100, NULL, NULL, NULL, NULL, 'Router ASUS RT-AC58U', NULL, '2 tháng', 'Router ASUS RT-AC58U', 6, 3),
(123, NULL, 1299999, 0, 100, NULL, NULL, NULL, NULL, 'Router ASUS RT-AC53', NULL, '2 tháng', 'Router ASUS RT-AC53', 6, 3),
(124, NULL, 120000, 1, 99, NULL, NULL, NULL, NULL, 'Camera Thân IP HikVision DS-2CD1023G0-I H265+', NULL, '2 tháng', 'Camera Thân IP HikVision DS-2CD1023G0-I H265+', 7, 2),
(125, NULL, 12000000, 0, 100, NULL, NULL, NULL, NULL, 'Camera IP Hikvision Dome HIK -HDIP2820FH 2.0M', NULL, '2 tháng', 'Camera IP Hikvision Dome HIK -HDIP2820FH 2.0M', 7, 2),
(126, NULL, 1200000, 0, 100, NULL, NULL, NULL, NULL, 'Camera Vantech FullHD HD-SDI VP-120HD', NULL, '2 tháng', 'Camera Vantech FullHD HD-SDI VP-120HD', 7, 2),
(127, NULL, 123000, 0, 100, NULL, NULL, NULL, NULL, 'Camera Dome Vantech VP- 4224T VT 1230', NULL, '2 tháng', 'Camera Dome Vantech VP- 4224T', 7, 2),
(128, NULL, 120000, 0, 100, NULL, NULL, NULL, NULL, 'Camera Thân TVI HikVision DS-2CE16C0T-IRP', NULL, '2 tháng', 'Camera Thân TVI HikVision DS-2CE16C0T-IRP', 7, 2),
(129, NULL, 120000, 0, 100, NULL, NULL, NULL, NULL, 'Camera Thân TVI HikVision DS-2CE16C0T-IRP', NULL, '2 tháng', 'Camera Thân TVI HikVision DS-2CE16C0T-IRP', 7, 2),
(130, NULL, 120000, 0, 100, NULL, NULL, NULL, NULL, 'Camera IP Vantech quay quét VT-6300C', NULL, '2 tháng', 'Camera IP Vantech quay quét VT-6300C', 7, 2),
(131, NULL, 100000, 0, 100, NULL, NULL, NULL, NULL, 'Camera IP Thân Hikvision DS-2CD2055FWD-I   H.265+', NULL, '2 tháng', 'Camera IP Thân Hikvision DS-2CD2055FWD-I   H.265+', 7, 3),
(132, NULL, 123000, 0, 100, NULL, NULL, NULL, NULL, 'Mouse Pad Madcatz G.L.I.D.E.7', NULL, '2 tháng', 'Mouse Pad Madcatz G.L.I.D.E.7', 8, 3),
(133, NULL, 0, 0, 100, NULL, NULL, NULL, NULL, 'Đế Làm Mát Laptop Cooling pad N99', NULL, '2 tháng', 'Đế Làm Mát Laptop Cooling pad N99', 8, 2),
(134, NULL, 123000, 0, 100, NULL, NULL, NULL, NULL, 'Mouse Pad Razer Goliathus SKT T1 Edition', NULL, '2 tháng', 'Mouse Pad Razer Goliathus SKT T1 Edition - Soft Gaming Mouse Mat - Medium - Speed  (355mm x 254mm)', 8, 4),
(135, NULL, 120000, 0, 100, NULL, NULL, NULL, NULL, 'Mouse Pad Razer Goliathus Medium 2014 (250x300mm)', NULL, '2 tháng', 'Mouse Pad Razer Goliathus Medium 2014 (250x300mm)', 8, 6),
(136, NULL, 120000, 0, 100, NULL, NULL, NULL, NULL, 'Cable HDMI 15m Vention', NULL, '1 tháng', 'Cable HDMI 15m Vention version 1.4', 9, 2),
(137, NULL, 120000, 0, 100, NULL, NULL, NULL, NULL, 'Cable HDMI dẹt 1.5m Vention ', NULL, '1 tháng', 'Cable HDMI dẹt 1.5m Vention version 1.4', 9, 3),
(138, NULL, 1500000, 0, 100, NULL, NULL, NULL, NULL, 'Cable màn hình VGA ', NULL, '1 tháng', 'Cable màn hình VGA 1m -1.5m (Từ cổng 15 đực sang 15 đực)', 9, 5),
(139, NULL, 120000, 1, 99, NULL, NULL, NULL, NULL, 'Cable HDMI dẹt 10m Vention version 1.4', NULL, '2 tháng', 'Cable HDMI dẹt 10m Vention version 1.4', 9, 5),
(140, NULL, 100000, 0, 100, NULL, NULL, NULL, NULL, 'Bộ chuyển đổi HDMI sang VGA', NULL, '1 tháng', 'Bộ chuyển đổi HDMI sang VGA( có Audio) Vention Black Metal Type', 9, 5),
(141, NULL, 100000, 0, 100, NULL, NULL, NULL, NULL, 'Cáp chuyển HDMI sang VGA ', NULL, '3 tháng', 'Cáp chuyển HDMI sang VGA Hỗ trợ Full HD DHTV-C20 Orico', 9, 5),
(142, NULL, 140000, 0, 100, NULL, NULL, NULL, NULL, 'Cable HDMI 1.5m', NULL, '2 tháng', 'Cable HDMI 1.5m Version 2.0 hỗ trợ 4K 60Mhz', 9, 3),
(143, NULL, 1000000, 0, 100, NULL, NULL, NULL, NULL, 'Cáp chuyển TypeC ', NULL, '2 tháng', 'Cáp chuyển TypeC sang 5 cổng HDMI/TypeC/2*USB 3.0 RCH3A-GD Orico', 9, 6),
(144, NULL, 30000, 0, 99, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(145, NULL, 9999, 0, 4, NULL, NULL, NULL, NULL, 'iPhone 13 Pro Max 128GB', NULL, '6 Tháng', 'iPhone 13 Pro Max xứng đáng là một chiếc iPhone lớn nhất, mạnh mẽ nhất và có thời lượng pin dài nhất từ trước đến nay sẽ cho bạn trải nghiệm tuyệt vời, từ những tác vụ bình thường cho đến các ứng dụng chuyên nghiệp.', 1, 2),
(146, NULL, 999, 0, 99, NULL, NULL, NULL, NULL, 'OPPO Reno7 Z 5G', NULL, '6 Tháng', 'OPPO Reno7 Z 5G', 1, 11),
(147, NULL, 99000000, 0, 99, NULL, NULL, NULL, NULL, 'Xiaomi Redmi Note 11S', NULL, '6 Tháng', 'Xiaomi Redmi Note 11S', 1, 12),
(148, NULL, 19999999, 0, 999, NULL, NULL, NULL, NULL, 'Samsung Galaxy S22 Ultra 5G', NULL, '6 Tháng', 'Samsung Galaxy S22 Ultra 5G', 1, 13),
(149, NULL, 888888888, 0, 99, NULL, NULL, NULL, NULL, 'iPhone 11 64GB ', NULL, '6 Tháng', 'iPhone 11 64GB ', 1, 2),
(150, NULL, 99999, 0, 99, NULL, NULL, NULL, NULL, 'Samsung Galaxy Z Fold3 5G', NULL, '6 Tháng', 'Samsung Galaxy Z Fold3 5G', 1, 13),
(151, NULL, 888888888, 0, 1, NULL, NULL, NULL, NULL, 'Xiaomi 11T', NULL, '6 Tháng', 'Xiaomi 11T', 1, 12),
(152, NULL, 9999999, 1, 32, NULL, NULL, NULL, NULL, 'Vivo Y21', NULL, '6 Tháng', 'Vivo Y21', 1, 14),
(153, NULL, 9999999, 0, 22, NULL, NULL, NULL, NULL, 'OPPO A95', NULL, '6 Tháng', 'OPPO A95', 1, 11),
(154, NULL, 9999999, 8, 991, NULL, NULL, NULL, NULL, 'Samsung Galaxy Z Flip3', NULL, '6 Tháng', 'Samsung Galaxy Z Flip3', 1, 13),
(155, NULL, 300000, 0, 55, NULL, NULL, NULL, NULL, 'Samsung Galaxy A22 5G', NULL, '6 Tháng', 'Samsung Galaxy A22 5G', 1, 13),
(156, NULL, 99999999, 6, 93, NULL, NULL, NULL, NULL, 'OPPO A95 8GB-128GB', NULL, '6 Tháng', 'Sở hữu vẻ ngoài hiện đại và sành điệu, OPPO A95 thuyết phục bạn ngay từ ánh nhìn đầu tiên. Không chỉ thế, mẫu điện thoại còn nâng tầm trải nghiệm cùng viên pin lớn, sạc nhanh 33W, hiệu năng ấn tượng và công nghệ mở rộng RAM.', 1, 11),
(157, NULL, 10000000, 0, 100, NULL, NULL, NULL, NULL, 'iPhone 12 64GB', NULL, '6 Tháng', 'iPhone 12 ra mắt với vai trò mở ra một kỷ nguyên hoàn toàn mới. Tốc độ mạng 5G siêu tốc, bộ vi xử lý A14 Bionic nhanh nhất thế giới smartphone, màn hình OLED tràn cạnh tuyệt đẹp và camera siêu chụp đêm, tất cả đều có mặt trên iPhone 12.', 1, 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `vai_tro`
--

CREATE TABLE `vai_tro` (
  `id` bigint(20) NOT NULL,
  `ten_vai_tro` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `vai_tro`
--

INSERT INTO `vai_tro` (`id`, `ten_vai_tro`) VALUES
(1, 'ROLE_ADMIN'),
(2, 'ROLE_MEMBER'),
(3, 'ROLE_SHIPPER');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chi_muc_gio_hang`
--
ALTER TABLE `chi_muc_gio_hang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK49lmmclnjgb7eck20lwhv0cks` (`ma_gio_hang`),
  ADD KEY `FKkd69a7wiulr4xgohxl0rlhth4` (`ma_san_pham`);

--
-- Chỉ mục cho bảng `chi_tiet_don_hang`
--
ALTER TABLE `chi_tiet_don_hang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK9wl3houbukbxpixsut6uvojhy` (`ma_don_hang`),
  ADD KEY `FK3ry84nmdxgoarx53qjxd671tk` (`ma_san_pham`);

--
-- Chỉ mục cho bảng `danh_muc`
--
ALTER TABLE `danh_muc`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `don_hang`
--
ALTER TABLE `don_hang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKnwjiboxao1uvw1siemkvs1jb9` (`ma_nguoi_dat`),
  ADD KEY `FKgndcrlvetoudr3jaif9b7ay37` (`ma_shipper`);

--
-- Chỉ mục cho bảng `gio_hang`
--
ALTER TABLE `gio_hang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKitverect56puwr47y7tyvy6er` (`ma_nguoi_dung`);

--
-- Chỉ mục cho bảng `hang_san_xuat`
--
ALTER TABLE `hang_san_xuat`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `lien_he`
--
ALTER TABLE `lien_he`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK6jm47uh7f94pc3wix0duvedde` (`ma_nguoi_tra_loi`);

--
-- Chỉ mục cho bảng `nguoidung_vaitro`
--
ALTER TABLE `nguoidung_vaitro`
  ADD PRIMARY KEY (`ma_nguoi_dung`,`ma_vai_tro`),
  ADD KEY `FKig6jxd861mqv02a8pn68r43fr` (`ma_vai_tro`);

--
-- Chỉ mục cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKqss6n6gtx6lhb7flcka9un18t` (`ma_danh_muc`),
  ADD KEY `FKchvjvgjnq8lbt9mjtyfn5pksq` (`ma_hang_sx`);

--
-- Chỉ mục cho bảng `vai_tro`
--
ALTER TABLE `vai_tro`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `chi_muc_gio_hang`
--
ALTER TABLE `chi_muc_gio_hang`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT cho bảng `chi_tiet_don_hang`
--
ALTER TABLE `chi_tiet_don_hang`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT cho bảng `danh_muc`
--
ALTER TABLE `danh_muc`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `don_hang`
--
ALTER TABLE `don_hang`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT cho bảng `gio_hang`
--
ALTER TABLE `gio_hang`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `hang_san_xuat`
--
ALTER TABLE `hang_san_xuat`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `lien_he`
--
ALTER TABLE `lien_he`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT cho bảng `vai_tro`
--
ALTER TABLE `vai_tro`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `chi_muc_gio_hang`
--
ALTER TABLE `chi_muc_gio_hang`
  ADD CONSTRAINT `FK49lmmclnjgb7eck20lwhv0cks` FOREIGN KEY (`ma_gio_hang`) REFERENCES `gio_hang` (`id`),
  ADD CONSTRAINT `FKkd69a7wiulr4xgohxl0rlhth4` FOREIGN KEY (`ma_san_pham`) REFERENCES `san_pham` (`id`);

--
-- Các ràng buộc cho bảng `chi_tiet_don_hang`
--
ALTER TABLE `chi_tiet_don_hang`
  ADD CONSTRAINT `FK3ry84nmdxgoarx53qjxd671tk` FOREIGN KEY (`ma_san_pham`) REFERENCES `san_pham` (`id`),
  ADD CONSTRAINT `FK9wl3houbukbxpixsut6uvojhy` FOREIGN KEY (`ma_don_hang`) REFERENCES `don_hang` (`id`);

--
-- Các ràng buộc cho bảng `don_hang`
--
ALTER TABLE `don_hang`
  ADD CONSTRAINT `FKgndcrlvetoudr3jaif9b7ay37` FOREIGN KEY (`ma_shipper`) REFERENCES `nguoi_dung` (`id`),
  ADD CONSTRAINT `FKnwjiboxao1uvw1siemkvs1jb9` FOREIGN KEY (`ma_nguoi_dat`) REFERENCES `nguoi_dung` (`id`);

--
-- Các ràng buộc cho bảng `gio_hang`
--
ALTER TABLE `gio_hang`
  ADD CONSTRAINT `FKitverect56puwr47y7tyvy6er` FOREIGN KEY (`ma_nguoi_dung`) REFERENCES `nguoi_dung` (`id`);

--
-- Các ràng buộc cho bảng `lien_he`
--
ALTER TABLE `lien_he`
  ADD CONSTRAINT `FK6jm47uh7f94pc3wix0duvedde` FOREIGN KEY (`ma_nguoi_tra_loi`) REFERENCES `nguoi_dung` (`id`);

--
-- Các ràng buộc cho bảng `nguoidung_vaitro`
--
ALTER TABLE `nguoidung_vaitro`
  ADD CONSTRAINT `FKig6jxd861mqv02a8pn68r43fr` FOREIGN KEY (`ma_vai_tro`) REFERENCES `vai_tro` (`id`),
  ADD CONSTRAINT `FKocavcnspu1wcvp2w0s4usfgbf` FOREIGN KEY (`ma_nguoi_dung`) REFERENCES `nguoi_dung` (`id`);

--
-- Các ràng buộc cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  ADD CONSTRAINT `FKchvjvgjnq8lbt9mjtyfn5pksq` FOREIGN KEY (`ma_hang_sx`) REFERENCES `hang_san_xuat` (`id`),
  ADD CONSTRAINT `FKqss6n6gtx6lhb7flcka9un18t` FOREIGN KEY (`ma_danh_muc`) REFERENCES `danh_muc` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
